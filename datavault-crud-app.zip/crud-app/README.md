# DataVault — 3-Layer CRUD Web Application

A full-stack CRUD application built with **React.js + Node.js + MySQL**.

## 🏗 Architecture

```
Layer 1 → Frontend   (React.js + React Router + Axios)
Layer 2 → Backend    (Node.js + Express.js + REST API)
Layer 3 → Database   (MySQL)
```

## 📁 Project Structure

```
crud-app/
├── frontend/          # React.js frontend
│   ├── public/
│   └── src/
│       ├── components/   # Sidebar, Navbar, UserForm, ToastContext
│       ├── layouts/      # AppLayout
│       ├── pages/        # Dashboard, InsertData, ViewData, UpdateData, DeleteData
│       ├── services/     # api.js (Axios)
│       └── styles/       # global.css
│
├── backend/           # Node.js + Express backend
│   ├── config/        # db.js (MySQL connection)
│   ├── controllers/   # userController.js
│   ├── middleware/    # logger.js, errorHandler.js
│   ├── models/        # userModel.js
│   ├── routes/        # userRoutes.js
│   ├── services/      # userService.js
│   └── server.js
│
└── database/
    └── setup.sql      # MySQL schema + sample data
```

## ⚡ Quick Start

### Step 1 — Set up MySQL Database

```sql
-- Open MySQL and run:
source /path/to/crud-app/database/setup.sql
```

Or manually:
```sql
CREATE DATABASE crud_application;
USE crud_application;
-- then run the CREATE TABLE statement from setup.sql
```

### Step 2 — Configure Backend

```bash
cd backend
cp .env.example .env   # or edit .env directly
```

Edit `backend/.env`:
```
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=crud_application
```

### Step 3 — Install & Run Backend

```bash
cd backend
npm install
npm run dev       # development (nodemon)
# or
npm start         # production
```

Backend runs at: **http://localhost:5000**

### Step 4 — Configure Frontend

Edit `frontend/.env`:
```
REACT_APP_API_URL=http://localhost:5000/api
```

### Step 5 — Install & Run Frontend

```bash
cd frontend
npm install
npm start
```

Frontend runs at: **http://localhost:3000**

---

## 🔌 REST API Endpoints

| Method | Endpoint           | Description         |
|--------|--------------------|---------------------|
| GET    | /api/users         | Get all users       |
| GET    | /api/users?search= | Search users        |
| GET    | /api/users/:id     | Get user by ID      |
| POST   | /api/users         | Create user         |
| PUT    | /api/users/:id     | Update user         |
| DELETE | /api/users/:id     | Delete user         |
| GET    | /api/health        | Server health check |

### Example Request (Create User)
```json
POST /api/users
{
  "username": "John Doe",
  "dob": "1995-06-15",
  "state": "Tamil Nadu",
  "city": "Chennai",
  "address": "123 Anna Salai",
  "email": "john@example.com",
  "phone": "9876543210",
  "gender": "Male",
  "qualification": "B.Tech / B.E.",
  "area": "T. Nagar"
}
```

---

## 🎨 Features

- ✅ Dashboard with live stats
- ✅ Insert user with full validation
- ✅ View all users with search & pagination
- ✅ Edit users via modal or dedicated page
- ✅ Delete with confirmation dialog
- ✅ Toast notifications
- ✅ Loading spinners & empty states
- ✅ Responsive design (dark theme)
- ✅ Logger middleware (colored console)
- ✅ Error handling middleware
- ✅ Email uniqueness check

## 🛠 Tech Stack

| Layer    | Technology                          |
|----------|-------------------------------------|
| Frontend | React 18, React Router 6, Axios     |
| Backend  | Node.js, Express 4, nodemon         |
| Database | MySQL 8 via mysql2                  |
| Styling  | Custom CSS with CSS Variables       |
| Fonts    | Sora, JetBrains Mono (Google Fonts) |

## 📋 Requirements

- Node.js >= 16
- MySQL >= 8.0
- npm >= 8
