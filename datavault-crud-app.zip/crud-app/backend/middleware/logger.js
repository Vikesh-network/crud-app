const loggerMiddleware = (req, res, next) => {
  const start = Date.now();
  const timestamp = new Date().toISOString();

  res.on('finish', () => {
    const duration = Date.now() - start;
    const method = req.method;
    const url = req.originalUrl;
    const status = res.statusCode;

    const color =
      status >= 500 ? '\x1b[31m' : // red
      status >= 400 ? '\x1b[33m' : // yellow
      status >= 300 ? '\x1b[36m' : // cyan
      status >= 200 ? '\x1b[32m' : // green
      '\x1b[0m';

    console.log(`${color}[${timestamp}] ${method} ${url} → ${status} (${duration}ms)\x1b[0m`);
  });

  next();
};

module.exports = { loggerMiddleware };
