const userService = require('../services/userService');
const { asyncHandler } = require('../middleware/errorHandler');

// GET /api/users
const getAllUsers = asyncHandler(async (req, res) => {
  const { search = '' } = req.query;
  const users = await userService.getAllUsers(search);
  res.json({ success: true, count: users.length, data: users });
});

// GET /api/users/:id
const getUserById = asyncHandler(async (req, res) => {
  const user = await userService.getUserById(req.params.id);
  res.json({ success: true, data: user });
});

// POST /api/users
const createUser = asyncHandler(async (req, res) => {
  const user = await userService.createUser(req.body);
  res.status(201).json({ success: true, message: 'User created successfully', data: user });
});

// PUT /api/users/:id
const updateUser = asyncHandler(async (req, res) => {
  const user = await userService.updateUser(req.params.id, req.body);
  res.json({ success: true, message: 'User updated successfully', data: user });
});

// DELETE /api/users/:id
const deleteUser = asyncHandler(async (req, res) => {
  await userService.deleteUser(req.params.id);
  res.json({ success: true, message: 'User deleted successfully' });
});

module.exports = { getAllUsers, getUserById, createUser, updateUser, deleteUser };
