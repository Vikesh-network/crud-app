const UserModel = require('../models/userModel');

class UserService {
  async getAllUsers(search) {
    return await UserModel.getAll(search);
  }

  async getUserById(id) {
    const user = await UserModel.getById(id);
    if (!user) {
      const err = new Error('User not found');
      err.statusCode = 404;
      throw err;
    }
    return user;
  }

  async createUser(data) {
    const emailTaken = await UserModel.emailExists(data.email);
    if (emailTaken) {
      const err = new Error('Email already exists');
      err.statusCode = 409;
      throw err;
    }
    const id = await UserModel.create(data);
    return await UserModel.getById(id);
  }

  async updateUser(id, data) {
    await this.getUserById(id); // throws 404 if not found
    const emailTaken = await UserModel.emailExists(data.email, id);
    if (emailTaken) {
      const err = new Error('Email already in use by another user');
      err.statusCode = 409;
      throw err;
    }
    await UserModel.update(id, data);
    return await UserModel.getById(id);
  }

  async deleteUser(id) {
    await this.getUserById(id); // throws 404 if not found
    await UserModel.delete(id);
    return true;
  }
}

module.exports = new UserService();
