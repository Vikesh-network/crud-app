const db = require('../config/db');

class UserModel {
  // Get all users with optional search
  static async getAll(search = '') {
    let query = `SELECT id, username, dob, state, city, address, email, phone, gender, qualification, area, created_at FROM users`;
    const params = [];

    if (search) {
      query += ` WHERE username LIKE ? OR email LIKE ? OR city LIKE ? OR state LIKE ?`;
      const like = `%${search}%`;
      params.push(like, like, like, like);
    }

    query += ` ORDER BY created_at DESC`;
    const [rows] = await db.execute(query, params);
    return rows;
  }

  // Get user by ID
  static async getById(id) {
    const [rows] = await db.execute(
      `SELECT * FROM users WHERE id = ?`, [id]
    );
    return rows[0] || null;
  }

  // Check email exists (excluding a specific id for updates)
  static async emailExists(email, excludeId = null) {
    let query = `SELECT id FROM users WHERE email = ?`;
    const params = [email];
    if (excludeId) {
      query += ` AND id != ?`;
      params.push(excludeId);
    }
    const [rows] = await db.execute(query, params);
    return rows.length > 0;
  }

  // Create user
  static async create(data) {
    const { username, dob, state, city, address, email, phone, gender, qualification, area } = data;
    const [result] = await db.execute(
      `INSERT INTO users (username, dob, state, city, address, email, phone, gender, qualification, area)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [username, dob, state, city, address, email, phone, gender, qualification, area]
    );
    return result.insertId;
  }

  // Update user
  static async update(id, data) {
    const { username, dob, state, city, address, email, phone, gender, qualification, area } = data;
    const [result] = await db.execute(
      `UPDATE users SET username=?, dob=?, state=?, city=?, address=?, email=?, phone=?, gender=?, qualification=?, area=? WHERE id=?`,
      [username, dob, state, city, address, email, phone, gender, qualification, area, id]
    );
    return result.affectedRows;
  }

  // Delete user
  static async delete(id) {
    const [result] = await db.execute(`DELETE FROM users WHERE id = ?`, [id]);
    return result.affectedRows;
  }
}

module.exports = UserModel;
