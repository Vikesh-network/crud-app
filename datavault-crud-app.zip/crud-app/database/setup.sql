-- ============================================
-- CRUD Application Database Setup
-- Run this file in MySQL to set up the database
-- ============================================

-- Create the database
CREATE DATABASE IF NOT EXISTS crud_application;

-- Use the database
USE crud_application;

-- Create the users table
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(100)  NOT NULL,
  dob           DATE          NOT NULL,
  state         VARCHAR(100)  NOT NULL,
  city          VARCHAR(100)  NOT NULL,
  address       TEXT          NOT NULL,
  email         VARCHAR(150)  NOT NULL UNIQUE,
  phone         VARCHAR(20)   NOT NULL,
  gender        ENUM('Male', 'Female', 'Other') NOT NULL,
  qualification VARCHAR(150)  NOT NULL,
  area          VARCHAR(150)  NOT NULL,
  created_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data (optional)
INSERT INTO users (username, dob, state, city, address, email, phone, gender, qualification, area) VALUES
('Alice Johnson',  '1995-03-15', 'California',  'Los Angeles', '123 Sunset Blvd',   'alice@example.com',  '9876543210', 'Female', 'B.Sc Computer Science', 'Downtown'),
('Bob Smith',      '1990-07-22', 'New York',     'New York City','456 Broadway Ave',  'bob@example.com',    '8765432109', 'Male',   'MBA',                   'Manhattan'),
('Carol Williams', '1998-11-08', 'Texas',        'Houston',     '789 Oak Street',    'carol@example.com',  '7654321098', 'Female', 'B.Tech IT',             'Midtown');

-- Verify
SELECT 'Database setup complete!' AS Status;
SELECT COUNT(*) AS total_users FROM users;
