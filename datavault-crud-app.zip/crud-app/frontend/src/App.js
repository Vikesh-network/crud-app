import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ToastProvider } from './components/ToastContext';
import AppLayout from './layouts/AppLayout';
import Dashboard  from './pages/Dashboard';
import InsertData from './pages/InsertData';
import ViewData   from './pages/ViewData';
import UpdateData from './pages/UpdateData';
import DeleteData from './pages/DeleteData';
import './styles/global.css';

function App() {
  return (
    <ToastProvider>
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/"       element={<Dashboard />}  />
            <Route path="/insert" element={<InsertData />} />
            <Route path="/view"   element={<ViewData />}   />
            <Route path="/update" element={<UpdateData />} />
            <Route path="/delete" element={<DeleteData />} />
            <Route path="*"       element={
              <div className="empty-state" style={{ marginTop: 80 }}>
                <div className="empty-icon">404</div>
                <h3>Page not found</h3>
              </div>
            } />
          </Routes>
        </AppLayout>
      </BrowserRouter>
    </ToastProvider>
  );
}

export default App;
