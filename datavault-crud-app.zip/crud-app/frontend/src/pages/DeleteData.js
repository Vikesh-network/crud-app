import React, { useState, useEffect } from 'react';
import { userAPI } from '../services/api';
import { useToast } from '../components/ToastContext';

const DeleteData = () => {
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [delUser, setDelUser] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [search, setSearch]   = useState('');
  const { addToast } = useToast();

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await userAPI.getAll();
      setUsers(res.data.data || []);
    } catch {
      addToast('Failed to load users', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchUsers(); }, []);

  const filtered = users.filter(u =>
    u.username.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    u.city.toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await userAPI.delete(delUser.id);
      addToast(`${delUser.username} has been deleted`, 'success');
      setDelUser(null);
      fetchUsers();
    } catch (err) {
      addToast(err.userMessage || 'Failed to delete user', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const formatDob = (dob) => dob ? new Date(dob).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

  return (
    <>
      <div className="page-header">
        <h1>Delete Data</h1>
        <p>Remove user records from the database — this action is irreversible</p>
      </div>

      <div className="card">
        <div style={{ background: 'rgba(255,101,132,0.07)', border: '1px solid rgba(255,101,132,0.2)', borderRadius: 'var(--radius-sm)', padding: '12px 16px', marginBottom: 24, display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: '1.1rem' }}>⚠️</span>
          <p style={{ fontSize: '0.82rem', color: 'var(--accent-secondary)' }}>
            Deleted records cannot be recovered. Please proceed with caution.
          </p>
        </div>

        <div className="table-toolbar">
          <div className="search-box">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search users..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
            {filtered.length} record{filtered.length !== 1 ? 's' : ''}
          </div>
        </div>

        {loading ? (
          <div className="spinner-container">
            <div className="spinner" />
            <p className="spinner-text">Loading records...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">{search ? '🔎' : '✅'}</div>
            <h3>{search ? 'No users match your search' : 'No records to delete'}</h3>
            <p>{search ? 'Try a different term' : 'Database is empty'}</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Username</th><th>Email</th><th>DOB</th>
                  <th>City</th><th>Gender</th><th>Phone</th><th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((u) => (
                  <tr key={u.id}>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem', color: 'var(--text-muted)' }}>#{u.id}</td>
                    <td style={{ fontWeight: 500 }}>{u.username}</td>
                    <td style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>{u.email}</td>
                    <td style={{ fontSize: '0.82rem' }}>{formatDob(u.dob)}</td>
                    <td>{u.city}</td>
                    <td><span className={`badge badge-${u.gender?.toLowerCase()}`}>{u.gender}</span></td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.82rem' }}>{u.phone}</td>
                    <td>
                      <button className="btn btn-danger btn-sm" onClick={() => setDelUser(u)}>
                        ⌫ Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Confirm Modal */}
      {delUser && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && !deleting && setDelUser(null)}>
          <div className="modal">
            <div className="modal-body" style={{ padding: '36px 28px', textAlign: 'center' }}>
              <div className="confirm-icon">🗑️</div>
              <p className="confirm-title">Delete Permanently?</p>
              <p className="confirm-text">
                You're about to delete <strong style={{ color: 'var(--text-primary)' }}>{delUser.username}</strong>
                <br />({delUser.email})
                <br /><br />
                This <strong style={{ color: 'var(--accent-secondary)' }}>cannot be undone</strong>.
              </p>

              {/* User card */}
              <div style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '14px 16px', margin: '20px 0', textAlign: 'left' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '0.8rem' }}>
                  <div><span style={{ color: 'var(--text-muted)' }}>ID:</span> <span style={{ fontFamily: 'var(--font-mono)' }}>#{delUser.id}</span></div>
                  <div><span style={{ color: 'var(--text-muted)' }}>City:</span> {delUser.city}</div>
                  <div><span style={{ color: 'var(--text-muted)' }}>Gender:</span> {delUser.gender}</div>
                  <div><span style={{ color: 'var(--text-muted)' }}>Phone:</span> {delUser.phone}</div>
                </div>
              </div>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'center', gap: 16 }}>
              <button className="btn btn-secondary btn-lg" onClick={() => setDelUser(null)} disabled={deleting}>Cancel</button>
              <button className="btn btn-danger btn-lg" onClick={handleDelete} disabled={deleting}>
                {deleting ? '⟳ Deleting...' : '⌫ Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default DeleteData;
