import React, { useState, useEffect } from 'react';
import { userAPI } from '../services/api';
import { useToast } from '../components/ToastContext';
import UserForm from '../components/UserForm';

const UpdateData = () => {
  const [users, setUsers]       = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading]   = useState(true);
  const [saving, setSaving]     = useState(false);
  const [search, setSearch]     = useState('');
  const { addToast } = useToast();

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await userAPI.getAll();
      setUsers(res.data.data || []);
    } catch {
      addToast('Failed to load users', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchUsers(); }, []);

  const filtered = users.filter(u =>
    u.username.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const handleUpdate = async (formData) => {
    setSaving(true);
    try {
      await userAPI.update(selected.id, formData);
      addToast(`${selected.username} updated successfully! ✅`, 'success');
      fetchUsers();
      setSelected(null);
    } catch (err) {
      addToast(err.userMessage || 'Update failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="page-header">
        <h1>Update Data</h1>
        <p>Select a user from the list to edit their record</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: selected ? '320px 1fr' : '1fr', gap: 20 }}>
        {/* User list */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)' }}>
            <h2 style={{ fontSize: '0.9rem', fontWeight: 600, marginBottom: 10 }}>Select User</h2>
            <div className="search-box" style={{ maxWidth: '100%' }}>
              <span className="search-icon">🔍</span>
              <input
                type="text"
                placeholder="Search users..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          <div style={{ maxHeight: 500, overflowY: 'auto' }}>
            {loading ? (
              <div className="spinner-container"><div className="spinner" /></div>
            ) : filtered.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">🔎</div>
                <h3>No users found</h3>
              </div>
            ) : (
              filtered.map((u) => (
                <div
                  key={u.id}
                  onClick={() => setSelected(u)}
                  style={{
                    padding: '14px 20px',
                    borderBottom: '1px solid rgba(108,99,255,0.07)',
                    cursor: 'pointer',
                    transition: 'var(--transition)',
                    background: selected?.id === u.id ? 'rgba(108,99,255,0.12)' : 'transparent',
                    borderLeft: selected?.id === u.id ? '3px solid var(--accent-primary)' : '3px solid transparent',
                  }}
                  onMouseEnter={(e) => { if (selected?.id !== u.id) e.currentTarget.style.background = 'var(--bg-card-hover)'; }}
                  onMouseLeave={(e) => { if (selected?.id !== u.id) e.currentTarget.style.background = 'transparent'; }}
                >
                  <p style={{ fontWeight: 500, fontSize: '0.875rem' }}>{u.username}</p>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 3 }}>{u.email}</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Edit form */}
        {selected && (
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24, paddingBottom: 20, borderBottom: '1px solid var(--border)' }}>
              <div>
                <h2 style={{ fontSize: '1rem', fontWeight: 600 }}>Editing: {selected.username}</h2>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: 3 }}>User ID #{selected.id}</p>
              </div>
              <button className="btn btn-secondary btn-sm" onClick={() => setSelected(null)}>✕ Close</button>
            </div>
            <UserForm key={selected.id} initialData={selected} onSubmit={handleUpdate} loading={saving} />
          </div>
        )}

        {!selected && !loading && (
          <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div className="empty-state">
              <div className="empty-icon">👈</div>
              <h3>Select a user to edit</h3>
              <p>Click any user from the list to load their details</p>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default UpdateData;
