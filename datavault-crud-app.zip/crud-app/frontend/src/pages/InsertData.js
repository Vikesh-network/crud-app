import React, { useState } from 'react';
import UserForm from '../components/UserForm';
import { userAPI } from '../services/api';
import { useToast } from '../components/ToastContext';

const InsertData = () => {
  const [loading, setLoading] = useState(false);
  const [resetKey, setResetKey] = useState(0);
  const { addToast } = useToast();

  const handleSubmit = async (formData) => {
    setLoading(true);
    try {
      await userAPI.create(formData);
      addToast('User created successfully! 🎉', 'success');
      setResetKey((k) => k + 1); // reset form
    } catch (err) {
      addToast(err.userMessage || 'Failed to create user', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="page-header">
        <h1>Insert Data</h1>
        <p>Fill in the form below to add a new user record to the database</p>
      </div>

      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24, paddingBottom: 20, borderBottom: '1px solid var(--border)' }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: 'rgba(108,99,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem' }}>＋</div>
          <div>
            <h2 style={{ fontSize: '1rem', fontWeight: 600 }}>New User Record</h2>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 2 }}>All fields marked with * are required</p>
          </div>
        </div>
        <UserForm key={resetKey} onSubmit={handleSubmit} loading={loading} />
      </div>
    </>
  );
};

export default InsertData;
