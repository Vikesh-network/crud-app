import React, { useState, useEffect, useCallback } from 'react';
import { userAPI } from '../services/api';
import { useToast } from '../components/ToastContext';
import UserForm from '../components/UserForm';

const ROWS_PER_PAGE = 8;

const ViewData = () => {
  const [users, setUsers]       = useState([]);
  const [search, setSearch]     = useState('');
  const [page, setPage]         = useState(1);
  const [loading, setLoading]   = useState(true);
  const [editUser, setEditUser] = useState(null);
  const [delUser, setDelUser]   = useState(null);
  const [saving, setSaving]     = useState(false);
  const [deleting, setDeleting] = useState(false);
  const { addToast } = useToast();

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await userAPI.getAll(search);
      setUsers(res.data.data || []);
      setPage(1);
    } catch {
      addToast('Failed to load users', 'error');
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  // Pagination
  const totalPages = Math.ceil(users.length / ROWS_PER_PAGE);
  const paginated  = users.slice((page - 1) * ROWS_PER_PAGE, page * ROWS_PER_PAGE);

  const handleUpdate = async (formData) => {
    setSaving(true);
    try {
      await userAPI.update(editUser.id, formData);
      addToast('User updated successfully!', 'success');
      setEditUser(null);
      fetchUsers();
    } catch (err) {
      addToast(err.userMessage || 'Failed to update user', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await userAPI.delete(delUser.id);
      addToast('User deleted successfully!', 'success');
      setDelUser(null);
      fetchUsers();
    } catch (err) {
      addToast(err.userMessage || 'Failed to delete user', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const formatDob = (dob) => {
    if (!dob) return '—';
    return new Date(dob).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
  };

  return (
    <>
      <div className="page-header">
        <h1>View Data</h1>
        <p>Browse and manage all user records stored in the database</p>
      </div>

      <div className="card">
        {/* Toolbar */}
        <div className="table-toolbar">
          <div className="search-box">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search by name, email, city..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              {users.length} record{users.length !== 1 ? 's' : ''} found
            </span>
            <button className="btn btn-secondary btn-sm" onClick={fetchUsers}>↺ Refresh</button>
          </div>
        </div>

        {/* Table */}
        {loading ? (
          <div className="spinner-container">
            <div className="spinner" />
            <p className="spinner-text">Loading records...</p>
          </div>
        ) : paginated.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">{search ? '🔎' : '🗃'}</div>
            <h3>{search ? 'No results found' : 'No records yet'}</h3>
            <p>{search ? 'Try a different search term' : 'Start by inserting data'}</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>DOB</th>
                  <th>State</th>
                  <th>City</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Gender</th>
                  <th>Qualification</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {paginated.map((u) => (
                  <tr key={u.id}>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem', color: 'var(--text-muted)' }}>#{u.id}</td>
                    <td style={{ fontWeight: 500 }}>{u.username}</td>
                    <td style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>{formatDob(u.dob)}</td>
                    <td style={{ fontSize: '0.85rem' }}>{u.state}</td>
                    <td>{u.city}</td>
                    <td style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>{u.email}</td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.82rem' }}>{u.phone}</td>
                    <td>
                      <span className={`badge badge-${u.gender?.toLowerCase()}`}>{u.gender}</span>
                    </td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{u.qualification}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-secondary btn-sm" onClick={() => setEditUser(u)}>✎ Edit</button>
                        <button className="btn btn-danger btn-sm" onClick={() => setDelUser(u)}>⌫ Del</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {!loading && users.length > ROWS_PER_PAGE && (
          <div className="pagination">
            <p className="pagination-info">
              Showing {(page - 1) * ROWS_PER_PAGE + 1}–{Math.min(page * ROWS_PER_PAGE, users.length)} of {users.length}
            </p>
            <div className="pagination-controls">
              <button className="page-btn" onClick={() => setPage(1)} disabled={page === 1}>«</button>
              <button className="page-btn" onClick={() => setPage(p => p - 1)} disabled={page === 1}>‹</button>
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(n => n === 1 || n === totalPages || Math.abs(n - page) <= 1)
                .map((n, idx, arr) => (
                  <React.Fragment key={n}>
                    {idx > 0 && arr[idx - 1] !== n - 1 && <span style={{ color: 'var(--text-muted)', padding: '0 4px' }}>…</span>}
                    <button className={`page-btn ${n === page ? 'active' : ''}`} onClick={() => setPage(n)}>{n}</button>
                  </React.Fragment>
                ))}
              <button className="page-btn" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>›</button>
              <button className="page-btn" onClick={() => setPage(totalPages)} disabled={page === totalPages}>»</button>
            </div>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editUser && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setEditUser(null)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <h2>✎ Edit User — #{editUser.id}</h2>
              <button className="modal-close" onClick={() => setEditUser(null)}>✕</button>
            </div>
            <div className="modal-body">
              <UserForm initialData={editUser} onSubmit={handleUpdate} loading={saving} />
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm Modal */}
      {delUser && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setDelUser(null)}>
          <div className="modal">
            <div className="modal-body" style={{ textAlign: 'center', padding: '36px 28px' }}>
              <div className="confirm-icon">🗑️</div>
              <p className="confirm-title">Delete User?</p>
              <p className="confirm-text">
                You're about to permanently delete <strong>{delUser.username}</strong>.<br />
                This action cannot be undone.
              </p>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'center' }}>
              <button className="btn btn-secondary" onClick={() => setDelUser(null)} disabled={deleting}>
                Cancel
              </button>
              <button className="btn btn-danger" onClick={handleDelete} disabled={deleting}>
                {deleting ? '⟳ Deleting...' : '⌫ Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ViewData;
