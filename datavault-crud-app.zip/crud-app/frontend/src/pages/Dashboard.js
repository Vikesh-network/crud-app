import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { userAPI } from '../services/api';

const Dashboard = () => {
  const [stats, setStats] = useState({ total: 0, male: 0, female: 0, other: 0 });
  const [loading, setLoading] = useState(true);
  const [recentUsers, setRecentUsers] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await userAPI.getAll();
        const users = res.data.data || [];
        setStats({
          total:  users.length,
          male:   users.filter(u => u.gender === 'Male').length,
          female: users.filter(u => u.gender === 'Female').length,
          other:  users.filter(u => u.gender === 'Other').length,
        });
        setRecentUsers(users.slice(0, 5));
      } catch {
        // error handled silently on dashboard
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const cards = [
    { label: 'Total Users',  value: stats.total,  icon: '👥', cls: 'purple' },
    { label: 'Male',         value: stats.male,   icon: '♂',  cls: 'green'  },
    { label: 'Female',       value: stats.female, icon: '♀',  cls: 'pink'   },
    { label: 'Other',        value: stats.other,  icon: '⚧',  cls: 'orange' },
  ];

  const quickActions = [
    { to: '/insert', icon: '＋', label: 'Add User',    sub: 'Insert new record',  color: 'var(--accent-primary)' },
    { to: '/view',   icon: '◧', label: 'View All',    sub: 'Browse records',     color: 'var(--accent-cyan)'    },
    { to: '/update', icon: '✎', label: 'Edit Record', sub: 'Update existing',    color: 'var(--accent-orange)'  },
    { to: '/delete', icon: '⌫', label: 'Delete',      sub: 'Remove records',     color: 'var(--accent-secondary)'},
  ];

  return (
    <>
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Welcome back, Admin — here's your data overview</p>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        {cards.map((c) => (
          <div className="stat-card" key={c.label}>
            <div className={`stat-icon ${c.cls}`}>{c.icon}</div>
            <div className="stat-info">
              <h3>{loading ? '—' : c.value}</h3>
              <p>{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="card" style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: '0.95rem', fontWeight: 600, marginBottom: 20, color: 'var(--text-secondary)' }}>
          Quick Actions
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14 }}>
          {quickActions.map((a) => (
            <Link to={a.to} key={a.to} style={{ textDecoration: 'none' }}>
              <div className="quick-action-card" style={{ '--qa-color': a.color }}>
                <div className="qa-icon">{a.icon}</div>
                <div>
                  <p className="qa-label">{a.label}</p>
                  <p className="qa-sub">{a.sub}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent */}
      <div className="card">
        <h2 style={{ fontSize: '0.95rem', fontWeight: 600, marginBottom: 20, color: 'var(--text-secondary)' }}>
          Recent Records
        </h2>
        {loading ? (
          <div className="spinner-container"><div className="spinner" /></div>
        ) : recentUsers.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🗃</div>
            <h3>No records yet</h3>
            <p>Start by inserting some data</p>
            <Link to="/insert" className="btn btn-primary" style={{ marginTop: 12 }}>Add First User</Link>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Username</th><th>Email</th><th>City</th><th>Gender</th>
                </tr>
              </thead>
              <tbody>
                {recentUsers.map((u) => (
                  <tr key={u.id}>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8rem', color: 'var(--text-muted)' }}>#{u.id}</td>
                    <td style={{ fontWeight: 500 }}>{u.username}</td>
                    <td style={{ color: 'var(--text-secondary)' }}>{u.email}</td>
                    <td>{u.city}</td>
                    <td>
                      <span className={`badge badge-${u.gender?.toLowerCase()}`}>{u.gender}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <style>{`
        .quick-action-card {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px;
          border-radius: var(--radius-sm);
          background: var(--bg-secondary);
          border: 1px solid var(--border);
          transition: var(--transition);
          cursor: pointer;
        }
        .quick-action-card:hover {
          border-color: var(--qa-color);
          background: var(--bg-card-hover);
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        }
        .qa-icon {
          width: 40px; height: 40px;
          border-radius: 10px;
          background: rgba(255,255,255,0.06);
          display: flex; align-items: center; justify-content: center;
          font-size: 1.1rem;
          color: var(--qa-color);
          flex-shrink: 0;
        }
        .qa-label { font-size: 0.875rem; font-weight: 600; color: var(--text-primary); }
        .qa-sub   { font-size: 0.75rem;  color: var(--text-muted); margin-top: 2px; }
      `}</style>
    </>
  );
};

export default Dashboard;
