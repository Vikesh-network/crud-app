import React, { useState, useEffect } from 'react';

const STATES = [
  'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh',
  'Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka',
  'Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram',
  'Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana',
  'Tripura','Uttar Pradesh','Uttarakhand','West Bengal',
  'California','New York','Texas','Florida','Other',
];

const QUALIFICATIONS = [
  'High School','Diploma','B.A.','B.Sc.','B.Com.','B.Tech / B.E.',
  'MBA','M.Sc.','M.Tech','MCA','Ph.D.','Other',
];

const INITIAL_STATE = {
  username: '', dob: '', state: '', city: '', address: '',
  email: '', phone: '', gender: '', qualification: '', area: '',
};

const UserForm = ({ initialData = null, onSubmit, onReset, loading }) => {
  const [form, setForm] = useState(INITIAL_STATE);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialData) {
      setForm({
        username:      initialData.username      || '',
        dob:           initialData.dob           ? initialData.dob.split('T')[0] : '',
        state:         initialData.state         || '',
        city:          initialData.city          || '',
        address:       initialData.address       || '',
        email:         initialData.email         || '',
        phone:         initialData.phone         || '',
        gender:        initialData.gender        || '',
        qualification: initialData.qualification || '',
        area:          initialData.area          || '',
      });
      setErrors({});
    }
  }, [initialData]);

  const validate = () => {
    const e = {};
    if (!form.username.trim())      e.username = 'Username is required';
    if (!form.dob)                  e.dob       = 'Date of birth is required';
    if (!form.state)                e.state     = 'State is required';
    if (!form.city.trim())          e.city      = 'City is required';
    if (!form.address.trim())       e.address   = 'Address is required';
    if (!form.email.trim())         e.email     = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
                                    e.email     = 'Invalid email format';
    if (!form.phone.trim())         e.phone     = 'Phone is required';
    else if (!/^\d{10}$/.test(form.phone.replace(/\s/g, '')))
                                    e.phone     = 'Enter a valid 10-digit number';
    if (!form.gender)               e.gender    = 'Gender is required';
    if (!form.qualification)        e.qualification = 'Qualification is required';
    if (!form.area.trim())          e.area      = 'Area is required';
    return e;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    if (errors[name]) setErrors((p) => ({ ...p, [name]: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    onSubmit(form);
  };

  const handleReset = () => {
    setForm(INITIAL_STATE);
    setErrors({});
    if (onReset) onReset();
  };

  const Field = ({ name, label, type = 'text', required = true, placeholder = '' }) => (
    <div className="form-group">
      <label className="form-label">
        {label}{required && <span className="required">*</span>}
      </label>
      <input
        type={type}
        name={name}
        value={form[name]}
        onChange={handleChange}
        placeholder={placeholder || label}
        className={`form-input${errors[name] ? ' error' : ''}`}
        max={type === 'date' ? new Date().toISOString().split('T')[0] : undefined}
      />
      {errors[name] && <span className="error-msg">⚠ {errors[name]}</span>}
    </div>
  );

  const Select = ({ name, label, options, required = true }) => (
    <div className="form-group">
      <label className="form-label">
        {label}{required && <span className="required">*</span>}
      </label>
      <select
        name={name}
        value={form[name]}
        onChange={handleChange}
        className={`form-select${errors[name] ? ' error' : ''}`}
      >
        <option value="">Select {label}</option>
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
      {errors[name] && <span className="error-msg">⚠ {errors[name]}</span>}
    </div>
  );

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div className="form-grid">
        <Field name="username" label="Username" placeholder="Full name" />
        <Field name="dob" label="Date of Birth" type="date" />
        <Select name="state" label="State" options={STATES} />
        <Field name="city" label="City" placeholder="City name" />
        <Field name="email" label="Email" type="email" placeholder="user@example.com" />
        <Field name="phone" label="Phone Number" placeholder="10-digit number" />
        <Select name="gender" label="Gender" options={['Male', 'Female', 'Other']} />
        <Select name="qualification" label="Qualification" options={QUALIFICATIONS} />
        <Field name="area" label="Area" placeholder="Locality / Area" />

        <div className="form-group">
          <label className="form-label">Address<span className="required">*</span></label>
          <textarea
            name="address"
            value={form.address}
            onChange={handleChange}
            placeholder="Full address"
            className={`form-textarea${errors.address ? ' error' : ''}`}
            rows={3}
          />
          {errors.address && <span className="error-msg">⚠ {errors.address}</span>}
        </div>

        <div className="form-actions">
          <button type="submit" className="btn btn-primary btn-lg" disabled={loading}>
            {loading ? '⟳ Saving...' : '✔ Save Record'}
          </button>
          <button type="button" className="btn btn-secondary btn-lg" onClick={handleReset} disabled={loading}>
            ↺ Reset
          </button>
        </div>
      </div>
    </form>
  );
};

export default UserForm;
