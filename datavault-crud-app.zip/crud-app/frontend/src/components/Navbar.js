import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import './Navbar.css';

const pageTitles = {
  '/':       { title: 'Dashboard',   sub: 'Overview of all records' },
  '/insert': { title: 'Insert Data', sub: 'Add a new user record'   },
  '/view':   { title: 'View Data',   sub: 'Browse all user records' },
  '/update': { title: 'Update Data', sub: 'Edit existing records'   },
  '/delete': { title: 'Delete Data', sub: 'Remove user records'     },
};

const Navbar = () => {
  const location = useLocation();
  const info = pageTitles[location.pathname] || pageTitles['/'];
  const [showMenu, setShowMenu] = useState(false);

  return (
    <header className="navbar">
      <div className="navbar-left">
        <div className="breadcrumb">
          <span className="breadcrumb-root">DataVault</span>
          <span className="breadcrumb-sep">›</span>
          <span className="breadcrumb-current">{info.title}</span>
        </div>
        <p className="navbar-sub">{info.sub}</p>
      </div>

      <div className="navbar-right">
        <div className="navbar-time">
          {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
        </div>

        <div className="profile-wrapper" onClick={() => setShowMenu(!showMenu)}>
          <div className="profile-avatar">AD</div>
          <div className="profile-info">
            <span className="profile-name">Admin</span>
            <span className="profile-role">Super User</span>
          </div>
          <span className="profile-chevron">{showMenu ? '▴' : '▾'}</span>

          {showMenu && (
            <div className="profile-dropdown">
              <div className="dropdown-item">👤 Profile</div>
              <div className="dropdown-item">⚙️ Settings</div>
              <div className="dropdown-divider" />
              <div className="dropdown-item danger">⏻ Logout</div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
