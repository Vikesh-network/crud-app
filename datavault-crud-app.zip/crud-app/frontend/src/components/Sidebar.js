import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './Sidebar.css';

const navItems = [
  { path: '/',        label: 'Dashboard',    icon: '⬡' },
  { path: '/insert',  label: 'Insert Data',  icon: '＋' },
  { path: '/view',    label: 'View Data',    icon: '◧' },
  { path: '/update',  label: 'Update Data',  icon: '✎' },
  { path: '/delete',  label: 'Delete Data',  icon: '⌫' },
];

const Sidebar = () => {
  const location = useLocation();

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon">DV</div>
        <div className="logo-text">
          <span className="logo-name">DataVault</span>
          <span className="logo-sub">CRUD Manager</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        <p className="nav-section-label">Navigation</p>
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === '/'}
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <span className="nav-icon">{item.icon}</span>
            <span className="nav-label">{item.label}</span>
            {location.pathname === item.path && <span className="nav-active-dot" />}
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="db-status">
          <span className="db-dot" />
          <span>MySQL Connected</span>
        </div>
        <p className="sidebar-version">v1.0.0</p>
      </div>
    </aside>
  );
};

export default Sidebar;
